import java.util.Scanner;

public class primeiroprograma {

public static void main(String[] args) {

    
        Scanner leitor = new Scanner(System.in);


        int valorDigitado;
        valorDigitado = leitor.nextInt();

        System.out.println("O Seu valor Digitado foi: " + valorDigitado);

}

}



