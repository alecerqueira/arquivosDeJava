  
public class segundoprograma {


    public static void main(String[] args) {
        
    //Declaração de variáveis de diversos tipos
        boolean isTrue = true;
        int numero = 10;
        String qualquerTexto = "Alexandre Lindo"; 
    char caracter = 'A';
    double dinheiro = 12.90;


    //O que será a saída do programa
        System.out.println(isTrue);
    System.out.println(numero);
    System.out.println(dinheiro);


    System.out.println(numero + dinheiro);
    //Resultado é decimal (double)


    System.out.println(numero + qualquerTexto);
    //Concatenação de texto
    System.out.println("Hoje e: " + "segunda-feira");


    System.out.println("O Valor e: " + isTrue);



    }


}