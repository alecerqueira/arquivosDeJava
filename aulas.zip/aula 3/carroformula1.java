public class carroformula1 {

    // Caracteristicas (Propriedades)
    // modificador de acesso - private / public / protected
    private String cor;

    // Metodo de Acesso - GET
    // é COMO PEDIR
    public String getCor() {
        return cor;
    }

    // Metodo de acesso - SET
    // é COMO ENTREGAR
    public void setCor(String novaCor) {
        cor = novaCor;
    }

    int cilindradas;
    int passageiros = 1;
    double portaMalasLitros = 0;

    // int portaMalas = 0;
    // boolean temPortaMalas = false;

    // String[] tamanhos = { "N", "P", "M", "G" };
    // String tamanhoDoCarro = tamanhos[0];

    // Ações (Métodos)
    public void frear() {
        System.out.println("Carro freando...");
        System.out.println("Carro parado !");
    }

    public void acelerar() {
        System.out.println("Carro acelerando...");
        System.out.println("Carro correndo !");

    }

    public void virar(String direcao) {
        System.out.println("Carro virando para a : " + direcao + " ...");
        System.out.println("Carro virou para a  : " + direcao + "!");
    }

    public CarroFormulaUm() {

    }
}