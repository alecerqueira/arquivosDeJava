public class ContaBancaria {

    private String nome;
    private String telefone;
    private String agencia;
    private String conta;
    private Double saldo;

    public String getNome() {
        return nome;
    }

    public void setNome(String novoNome) {
        nome = novoNome;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String novoTelefone) {
        telefone = novoTelefone;
    }

    public String getAgencia() {
        return agencia;
    }

    // public void setAgencia(String novoAgencia) {
    // agencia = novoAgencia;
    // }

    public String getConta() {
        return conta;
    }

    // public void setConta(String novoConta) {
    // conta = novoConta;
    // }

    // public Double getSaldo() {
    // return saldo;
    // }

    // public void setSaldo(Double novoSaldo) {
    // saldo = novoSaldo;
    // }

    public ContaBancaria(String agenciaCadastrada, String contaCadastrada) {
        agencia = agenciaCadastrada;
        conta = contaCadastrada;
        saldo = 0.0;
    }

    public void transferencia(String agencia, String conta, Double valor) {

    }

    public void transferencia(String telefone, Double valor) {

    }

    public void saque(Double valorSacado) {
        saldo -= valorSacado;

    }

    public void depositar(Double valorDepositado) {
        saldo += valorDepositado;
    }

    public Double exibirSaldo() {
        return saldo;
    }

    public void migrarConta(String novaAgencia, String novaConta) {
        conta = novaConta;
        agencia = novaAgencia;
    }

}