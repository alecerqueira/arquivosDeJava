import java.util.Scanner;
 
public class Banco {
 
    public static void main(String[] args) {
 
        Scanner leitor = new Scanner(System.in);
 
        String cliente1 = "FERNANDA";
        double saldo1 = 5000.0;
 
        String cliente2 = "ALEXANDRE";
        double saldo2 = 8000.0; 
 
        boolean nomecliente = true;
 
        while (nomecliente) {
 
            System.out.println("Digite o seu nome: ");
            String nome = leitor.next();
 
        switch (nome.toUpperCase()) {
            case "FERNANDA":
                System.out.println("Seu saldo é: R$" + saldo1);
                System.out.println("Digite o valor que deseja transferir: R$");
                double valortransf1 = leitor.nextDouble();
                if (valortransf1 > saldo1) {
                    System.out.println("Saldo insuficiente para transferência");
                } else {
                    saldo1 -= valortransf1;
                    saldo2 += valortransf1;
                    System.out.println("Seu saldo atualizado é: R$" + saldo1);
                    System.out.println("Transferência realizada com sucesso");
                }
                nomecliente = false;
                break;
            case "ALEXANDRE":
                System.out.println("Seu saldo é: R$" + saldo2);
                System.out.println("Digite o valor que deseja transferir: R$");
                double valortransf2 = leitor.nextDouble();
                if (valortransf2 > saldo2) {
                    System.out.println("Saldo insuficiente para transferência");
                } else {
                    saldo2 -= valortransf2;
                    saldo1 += valortransf2;
                    System.out.println("Seu saldo atualizado é: R$" + saldo2);
                    System.out.println("Transferência realizada com sucesso");
                }
                nomecliente = false;
                break;
            default:
                System.out.println("Cliente inválido, digite novamente");
                nomecliente = true;
                break;     
        
    
        // Menu Interativo
        // 1 - Criar usuario Alice
        // 2 - Criar usuario Bob
        // 3 - Tranferir da Alice para o BOB
        // 4 - Tranferir do Bob para Alice
        // 5 - Exibir Saldo em reais
        // 6 - Saio do programa
        // diferente - Opção Invalida
 
        // 1 e 2 - Criar usuario
        // Preciso definir o nome dela
        // Definir Saldo Inicial
 
        // 3 e 4 - Tranferencias
        // Perguntar valor a ser transferido
        // Verificar existe saldo
        // Incrementar o saldo de um e decrementar o saldo do outro
 
        // 5 - Exibir Saldo
        // Perguntar de quem deve ser exibido o saldo
        // Exibir saldo da pessoa caso o nome esteja correto
        // avisar caso nome não seja encontrado
 
 
        }
    }
 
  }

}
