import java.util.Scanner;
 
public class Switch {
 
    public static void main(final String[] args) {

        final Scanner leitor = new Scanner(System.in);

        boolean nomeimposto = true;

        while (nomeimposto) {

            System.out.println("Digite o nome do imposto a ser calculado");
            final String impostoDigitado = leitor.nextLine();

            switch (impostoDigitado) {
                case "ICMS":
                    System.out.print("Digite o Valor para aplicar o ICMS: R$");
                    final double valor1 = leitor.nextDouble();
                    final double resultado1 = valor1 * 0.10;
                    System.out.println("Valor a ser pago: R$" + resultado1);
                    nomeimposto = false;
                    break;
                case "IPI":
                    System.out.print("Digite o Valor para aplicar o IPI: R$");
                    final double valor2 = leitor.nextDouble();
                    final double resultado2 = valor2 * 0.05;
                    System.out.println("Valor a ser pago: R$" + resultado2);
                    nomeimposto = false;
                    break;
                case "ISS":
                    System.out.print("Digite o Valor para aplicar o ISS: R$");
                    final double valor3 = leitor.nextDouble();
                    final double resultado3 = valor3 * 0.15;
                System.out.println("Valor a ser pago: R$" + resultado3);
                nomeimposto = false;
                break;
            default:
                System.out.println("Imposto invalido, digite novamente");
                nomeimposto = true;
                break;
 
        }
            
        }
        leitor.close();
    }
 
}
