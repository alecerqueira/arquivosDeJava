public class Banco {
    
    public static void main(String[] args) {
 
        System.out.println("Digite seu nome: ");
        String cliente = leitor.nextString();
     
            // Menu Interativo
            // 1 - Criar usuario Alice
            // 2 - Criar usuario Bob
            // 3 - Tranferir da Alice para o BOB
            // 4 - Tranferir do Bob para Alice
            // 5 - Exibir Saldo em reais
            // 6 - Saio do programa
            // diferente - Opção Invalida
     
            // 1 e 2 - Criar usuario
            // Preciso definir o nome dela
            // Definir Saldo Inicial
     
            // 3 e 4 - Tranferencias
            // Perguntar valor a ser transferido
            // Verificar existe saldo
            // Incrementar o saldo de um e decrementar o saldo do outro
     
            // 5 - Exibir Saldo
            // Perguntar de quem deve ser exibido o saldo
            // Exibir saldo da pessoa caso o nome esteja correto
            // avisar caso nome não seja encontrado
     
        }
     
    }
}