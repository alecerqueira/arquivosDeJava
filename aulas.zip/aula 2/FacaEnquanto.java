import java.util.Scanner;
 
public class FacaEnquanto {
 
    public static void main(String[] args) {
 
        Scanner leitor = new Scanner(System.in);
        
        // Do While -> eu executo, e depois pergunto se é verdeiro
        boolean menorDeIdade;
        do {
 
            System.out.print("Digite sua idade: ");
            int idade = leitor.nextInt();
 
            if (idade >= 18) {
                System.out.println("Você é maior de idade e pode dirigir");
                menorDeIdade = false;
            } else {
                System.out.println(" Você não é maior de idade. Responda novamente");
                menorDeIdade = true;
            }
 
        } while (menorDeIdade);
        leitor.close();
 
    }
}

