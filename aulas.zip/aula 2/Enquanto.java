import java.util.Scanner;
 
public class Enquanto {
 
    public static void main(final String[] args) {

        final Scanner leitor1 = new Scanner(System.in);

        boolean menorDeIdade = true;

        // While -> Eu pergunto, e se verdadeiro, eu executo e depois repito
        while (menorDeIdade) {
            System.out.print("Digite sua idade: ");
            final int idade = leitor1.nextInt();
 
            if (idade >= 18) {
                System.out.println("Você é maior de idade e pode dirigir");
                menorDeIdade = false;
            } else {
                System.out.println(" Você não é maior de idade. Responda novamente");

                
            }
            
        }
          
        leitor1.close();  
    }
}