import java.util.Scanner;
 
public class resultadonotas {
 
    public static void main(final String[] args) {
 
        Scanner leitor = new Scanner(System.in);
 
        System.out.print("Digite as 4 notas para fazermos a média: ");
        double nota1 = leitor.nextDouble();
        double nota2 = leitor.nextDouble();
        double nota3 = leitor.nextDouble();
        double nota4 = leitor.nextDouble();
 
        double valorMedia = media(nota1, nota2, nota3, nota4);
 
        System.out.println(valorMedia); 
        
        if (valorMedia >= 7.5){
            System.out.println("Aprovado");
        } else {
            System.out.println("Reprovado");
        }
 
        leitor.close();
    }
 
    public static double media(double nota1, double nota2, double nota3, double nota4) {
        double resultado = ((nota1 + nota2 + nota3 + nota4)/4);
        return resultado;
    } 
 
    }