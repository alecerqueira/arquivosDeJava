public class tabuada {

 

    public static void main(String[] args) {

 

        int multiplicador = 5;

 

        // Incrementadores e decrementadores
        int a = 2;
        int b = 3;
        int c = a + b;
        c = c + 1;
        b--;
        --b;
        c -= 10;
        c *= 5;

 

        // Laço de repetição FOR
        for (int contador = 0; contador <= 10; contador++) {
            int resultado = multiplicador * contador;
            System.out.println("O Resultado de " + multiplicador + " x " + contador + " = " + resultado);
        }

 

        System.out.println("Programa finalizado ");
    }

 

}