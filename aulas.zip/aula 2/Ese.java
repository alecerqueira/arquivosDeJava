import java.util.Scanner;
 
public class Ese {
 
    public static void main(String[] args) {
 
        Scanner leitor = new Scanner(System.in);
 
        System.out.print("Digite sua idade: ");
        int idade = leitor.nextInt();
 
        System.out.println(
                "Digite 0 caso você não tenha doenças respiratórios ou digite 1 caso você tenha alguma doençã respiratória");
        int dr = leitor.nextInt();
 
        // && operador AND que inclui condições
        // || operador OR que testa individualmente as condições
        if (idade >= 60 || dr == 1) {
            System.out.println("Redobre a atenção e não saia de casa !");
            // else if (algumacoisa) - que cria uma terceira ou maior via de comparações
        } else {
            System.out.println("Use mascara se precisar sair de casa !");
        }
 
        leitor.close();
 
    }
 
}