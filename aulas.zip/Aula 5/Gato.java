public class Gato extends Mamifero {

    public void emitirSom() {
        System.out.println("MIAIU MIAU MIAU !!!");
    }

}