public class Leao extends Mamifero {

    public void comer() {
        System.out.println("Leão Comendo");
    }
}
