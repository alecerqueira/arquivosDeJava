public class Ave extends Animal {

    public double bico; // em centimetros

    public String corPenas;

    public int pernas;

    public void botarOvo() {

    }

    public void voar() {
    }

}