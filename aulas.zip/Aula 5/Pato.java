public class Pato extends Ave {

    public void bicar() {
        System.out.println("Pato bicando !!");

    }

}