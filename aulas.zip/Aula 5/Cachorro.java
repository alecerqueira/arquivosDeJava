public class Cachorro extends Mamifero {

    public void emitirSom() {
        System.out.println("AU AU AU AU !");
    }

    // public Cachorro() {
    // }

}