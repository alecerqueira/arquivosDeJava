/**
 * Mamifero
 */
public class Mamifero extends Animal {

    public void morder() {
        System.out.println("MORDEU!!!!!");
    }

}