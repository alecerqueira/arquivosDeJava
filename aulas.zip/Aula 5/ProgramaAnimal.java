public class ProgramaAnimal {

    public static void main(String[] args) {

        Cachorro cao = new Cachorro();
        cao.setCor("caramelo");
        cao.setRaca("vira-lata");

        System.out.println(cao.getCor());
        System.out.println(cao.getRaca());

        cao.emitirSom();
        cao.morder();

        Gato gato = new Gato();
        gato.setCor("preto");
        gato.setRaca("siames");

        System.out.println(gato.getCor());
        System.out.println(gato.getRaca());

        gato.emitirSom();
        gato.morder();

        Pato patinho = new Pato();
        patinho.setCor("Amarelo");
        patinho.voar();

        System.out.println(patinho.getCor());
        patinho.bicar();

        Avestruz avenstruz = new Avestruz();
        avenstruz.corPenas = "Cinza";
        // TODO: Refactor
        avenstruz.voar();

        System.out.println(avenstruz.corPenas);
    }

}