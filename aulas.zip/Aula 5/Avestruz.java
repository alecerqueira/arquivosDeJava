public class Avestruz extends Ave {
    public void comer() {
        System.out.println("Avestruz Comendo");
    }
}