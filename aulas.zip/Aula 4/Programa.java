import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
 
public class Programa {
 
    public static void main(final String[] args) {
 
        Scanner leitor = new Scanner(System.in);
 
        List<ContaBancaria> listaContas = new ArrayList<ContaBancaria>();
 
        // ContaBancaria contaUm = new ContaBancaria("JC", novaConta());
        // ContaBancaria contaDois = new ContaBancaria("Andrei", novaConta());
        // ContaBancaria contaTres = new ContaBancaria("Beatriz", novaConta());
        // listaContas.add(contaUm);
        // listaContas.add(contaDois);
        // listaContas.add(contaTres);
 
        int opcaoSelecionada;
        do {
 
            System.out.println("Selecione uma opção: ");
            System.out.println("1 - Criar conta: ");
            System.out.println("2 - Listar todas as contas: ");
            System.out.println("3 - Transferência: ");
            System.out.println("4 - Depósito: ");
            System.out.println("5 - Saque: ");
            System.out.println("0 - Sair ");
            opcaoSelecionada = leitor.nextInt();

            switch (opcaoSelecionada) {
                // Errata
                // NextLine -> "Ouviram do ipiranga as margens......\\s+"
                // Next -> "Ouviram"
 
                // Criar Conta
                case 1:
                System.out.println("Digite nome para conta: ");
                    final String nome = leitor.next().trim().toLowerCase();
                    final ContaBancaria novaContaBancaria = new ContaBancaria(nome, novaConta());
                    listaContas.add(novaContaBancaria);
                    break;
                // Listar Todas as Contas
                case 2:
                    for (int contador = 0; contador < listaContas.size(); contador++) {
 
                        final ContaBancaria contaTemporaria = (ContaBancaria) listaContas.get(contador);
                        System.out.println("[Nome do Correntista]: " + contaTemporaria.getNome());
                        System.out.println("[Saldo do Correntista]: " + contaTemporaria.exibirSaldo());
                        System.out.println("[Conta do Correntista]: " + contaTemporaria.getConta());
                        System.out.println("-------------------------------------------------------");
                    }
                    break;
                case 3:
                    System.out.println("Digite a conta origem para efetuar a transferência: ");

                    int conta1 = leitor.nextInt();
                    
                    System.out.println("Digite a conta destino para efetuar a transferência: ");

                    int conta2 = leitor.nextInt();

                    for (int contador = 0; contador < listaContas.size(); contador++) {
 
                        ContaBancaria elemento = (ContaBancaria) listaContas.get(contador);
 
                        if (conta1 == elemento.getConta()) {
                            System.out.println("Seu saldo é: R$" + elemento.exibirSaldo());
                            System.out.print("Digite o valor da transferência: R$");
                            double valortransf = leitor.nextDouble();
                            if (valortransf > elemento.exibirSaldo()) {
                            System.out.println("Saldo insuficiente para transação");
                            } else{
                            valortransf -= elemento.exibirSaldo();
                            System.out.println("Transferência realizada com sucesso!");
                        }
                            
                        } else {
                            System.out.println("Conta não cadastrada. Favor cadastrar nova conta");
                    }   
                }         
                break;   
                case 4:
                    System.out.println("Digite a conta para efetuar depósito: ");

                    int conta = leitor.nextInt();
                       
                    for (int contador = 0; contador < listaContas.size(); contador++) {
 
                        ContaBancaria elemento = (ContaBancaria) listaContas.get(contador);
 
                        if (conta == elemento.getConta()) {
                            System.out.println("Seu saldo é: R$" + elemento.exibirSaldo());
                            System.out.print("Digite o valor do depósito: R$");
                            double depositar = leitor.nextDouble();
                            System.out.println("Depósito realizado com sucesso!");
                            System.out.println("Seu novo saldo é: R$" + elemento.exibirSaldo());
                        } else {
                            System.out.println("Conta não cadastrada. Favor cadastrar nova conta");
                    }   
                }         
                break;
                case 5:
                    System.out.println("Digite a conta para efetuar a saque: ");

                    int contas = leitor.nextInt();
                       
                    for (int contador = 0; contador < listaContas.size(); contador++) {
 
                        ContaBancaria elemento = (ContaBancaria) listaContas.get(contador);
 
                        if (contas == elemento.getConta()) {
                            System.out.println("Seu saldo é: R$" + elemento.exibirSaldo());
                            System.out.print("Digite o valor da saque: R$");
                            double valorsaque = leitor.nextDouble();
                            if (valorsaque > elemento.exibirSaldo()) {
                            System.out.println("Saldo insuficiente para transação");
                            } else{
                            valorsaque -= elemento.exibirSaldo();
                            System.out.println("Saque realizado com sucesso!");
                        }
                            
                        } else {
                            System.out.println("Conta não cadastrada. Favor cadastrar nova conta");
                    }   
                }         
                break;
                case 0:
                break;
                default:
                    System.out.println("Opção Inválida - Digite Novamente");
                break;
            }
        } while (opcaoSelecionada != 0);
 
        leitor.close();
 
    }
 
    public static int ids = 0;
 
    public static int novaConta() {
        return ids += 1;
    }
 
}