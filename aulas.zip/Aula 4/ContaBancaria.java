public class ContaBancaria {

    private String nome;
    private Double saldo;
    private Integer conta;

    public void setNome(String novoNome) {
        nome = novoNome;
    }

    public String getNome() {
        return nome;
    }

    public Integer getConta() {
        return conta;
    }

    // public void setSaldo(Double novoSaldo) {
    // saldo = novoSaldo;
    // }

    // public Double getSaldo() {
    // return saldo;
    // }

    public ContaBancaria(String nomeCorrentista, Integer numeroConta) {
        nome = nomeCorrentista;
        saldo = 0.0;
        conta = numeroConta;
    }

    public Double exibirSaldo() {
        return saldo;
    }

    public void depositar(Double valorDepositado) {
        saldo += valorDepositado;
    }

    public void sacar(Double valorSacado) {
        saldo -= valorSacado;
    }

    public void transferir(Double valorTransferido) {
        saldo -= valorTransferido;
    }
}